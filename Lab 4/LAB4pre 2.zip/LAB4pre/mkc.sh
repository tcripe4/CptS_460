
arm-none-eabi-gcc -c -mcpu=arm926ej-s queue.c -o queue.o






